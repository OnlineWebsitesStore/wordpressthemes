Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/nimal/
Buy theme: http://smthemes.com/buy/nimal/
Support Forums: http://smthemes.com/support/forum/nimal-free-wordpress-theme/