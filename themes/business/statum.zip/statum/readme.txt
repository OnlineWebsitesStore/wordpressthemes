Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/statum/
Buy theme: http://smthemes.com/buy/statum/
Support Forums: http://smthemes.com/support/forum/statum-free-wordpress-theme/