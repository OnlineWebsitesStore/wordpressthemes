Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/metal/
Buy theme: http://smthemes.com/buy/metal/
Support Forums: http://smthemes.com/support/forum/metal-free-wordpress-theme/