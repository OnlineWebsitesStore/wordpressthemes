Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/note/
Buy theme: http://smthemes.com/buy/note/
Support Forums: http://smthemes.com/support/forum/note-free-wordpress-theme/