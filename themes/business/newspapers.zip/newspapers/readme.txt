Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/newspapers/
Buy theme: http://smthemes.com/buy/newspapers/
Support Forums: http://smthemes.com/support/forum/newspapers-free-wordpress-theme/