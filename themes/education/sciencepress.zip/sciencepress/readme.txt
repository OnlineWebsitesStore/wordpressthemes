Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/sciencepress/
Buy theme: http://smthemes.com/buy/sciencepress/
Support Forums: http://smthemes.com/support/forum/sciencepress-free-wordpress-theme/