Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/wpaper/
Buy theme: http://smthemes.com/buy/wpaper/
Support Forums: http://smthemes.com/support/forum/wpaper-free-wordpress-theme/