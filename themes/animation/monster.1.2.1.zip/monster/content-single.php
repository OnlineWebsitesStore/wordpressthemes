<?php
/**
 * @package Monster
 * @since Monster 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>

		<div class="entry-meta">
			<?php monster_posted_on(); ?>
		</div><!-- .entry-meta -->
	</header><!-- .entry-header -->

	<div class="entry-content">
		<?php the_content(); ?>
		<?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'monster' ), 'after' => '</div>' ) ); ?>
	</div><!-- .entry-content -->

	<footer class="entry-meta">
		<?php
			$categories_list = get_the_category_list( ' ' );
			if ( $categories_list && monster_categorized_blog() ) :
		?>
		<span class="cat-links">
			<?php printf( __( '%1$s', 'monster' ), $categories_list ); ?>
		</span>
		<?php endif; // End if categories ?>

		<?php
			$tags_list = get_the_tag_list( '', ' ' );
			if ( $tags_list ) :
		?>
		<span class="tag-links">
			<?php printf( __( '%1$s', 'monster' ), $tags_list ); ?>
		</span>
		<?php endif; // End if $tags_list ?>

		<?php edit_post_link( __( 'Edit', 'monster' ), '<span class="edit-link">', '</span>' ); ?>
	</footer><!-- .entry-meta -->
</article><!-- #post-## -->
