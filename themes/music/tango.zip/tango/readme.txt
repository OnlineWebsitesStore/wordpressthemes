Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/tango/
Buy theme: http://smthemes.com/buy/tango/
Support Forums: http://smthemes.com/support/forum/tango-free-wordpress-theme/