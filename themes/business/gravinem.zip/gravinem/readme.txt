Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/gravinem/
Buy theme: http://smthemes.com/buy/gravinem/
Support Forums: http://smthemes.com/support/forum/gravinem-free-wordpress-theme/