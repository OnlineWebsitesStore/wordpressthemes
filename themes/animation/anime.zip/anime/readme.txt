Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/anime/
Buy theme: http://smthemes.com/buy/anime/
Support Forums: http://smthemes.com/support/forum/anime-free-wordpress-theme/