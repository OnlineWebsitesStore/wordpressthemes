Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/wackisl/
Buy theme: http://smthemes.com/buy/wackisl/
Support Forums: http://smthemes.com/support/forum/wackisl-free-wordpress-theme/