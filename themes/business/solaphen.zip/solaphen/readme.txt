Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/solaphen/
Buy theme: http://smthemes.com/buy/solaphen/
Support Forums: http://smthemes.com/support/forum/solaphen-free-wordpress-theme/