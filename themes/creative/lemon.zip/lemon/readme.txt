Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/lemon/
Buy theme: http://smthemes.com/buy/lemon/
Support Forums: http://smthemes.com/support/forum/lemon-free-wordpress-theme/