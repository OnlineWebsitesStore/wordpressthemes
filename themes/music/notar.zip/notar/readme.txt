Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/notar/
Buy theme: http://smthemes.com/buy/notar/
Support Forums: http://smthemes.com/support/forum/notar-free-wordpress-theme/