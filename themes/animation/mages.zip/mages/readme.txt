Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/mages/
Buy theme: http://smthemes.com/buy/mages/
Support Forums: http://smthemes.com/support/forum/mages-free-wordpress-theme/