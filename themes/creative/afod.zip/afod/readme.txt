Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/photobank/
Buy theme: http://smthemes.com/buy/photobank/
Support Forums: http://smthemes.com/support/forum/photobank-free-wordpress-theme/