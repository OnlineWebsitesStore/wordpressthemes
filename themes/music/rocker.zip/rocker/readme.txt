Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/rocker/
Buy theme: http://smthemes.com/buy/rocker/
Support Forums: http://smthemes.com/support/forum/rocker-free-wordpress-theme/