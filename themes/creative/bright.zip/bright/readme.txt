Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/bright/
Buy theme: http://smthemes.com/buy/bright/
Support Forums: http://smthemes.com/support/forum/bright-free-wordpress-theme/