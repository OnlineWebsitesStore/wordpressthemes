Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/silhar/
Buy theme: http://smthemes.com/buy/silhar/
Support Forums: http://smthemes.com/support/forum/silhar-free-wordpress-theme/