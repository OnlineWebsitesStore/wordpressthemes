Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/molecula/
Buy theme: http://smthemes.com/buy/molecula/
Support Forums: http://smthemes.com/support/forum/molecula-free-wordpress-theme/