Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/soundstream/
Buy theme: http://smthemes.com/buy/soundstream/
Support Forums: http://smthemes.com/support/forum/soundstream-free-wordpress-theme/