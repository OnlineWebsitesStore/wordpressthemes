Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/coisp/
Buy theme: http://smthemes.com/buy/coisp/
Support Forums: http://smthemes.com/support/forum/coisp-free-wordpress-theme/