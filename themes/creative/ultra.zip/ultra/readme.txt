Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/ultra/
Buy theme: http://smthemes.com/buy/ultra/
Support Forums: http://smthemes.com/support/forum/ultra-free-wordpress-theme/