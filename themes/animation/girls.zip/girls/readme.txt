Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/girls/
Buy theme: http://smthemes.com/buy/girls/
Support Forums: http://smthemes.com/support/forum/girls-free-wordpress-theme/