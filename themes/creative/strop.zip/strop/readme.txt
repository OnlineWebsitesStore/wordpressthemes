Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/strop/
Buy theme: http://smthemes.com/buy/strop/
Support Forums: http://smthemes.com/support/forum/strop-free-wordpress-theme/