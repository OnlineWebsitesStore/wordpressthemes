Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/education/
Buy theme: http://smthemes.com/buy/education/
Support Forums: http://smthemes.com/support/forum/education-free-wordpress-theme/