Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/work/
Buy theme: http://smthemes.com/buy/work/
Support Forums: http://smthemes.com/support/forum/work-free-wordpress-theme/