Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/popart/
Buy theme: http://smthemes.com/buy/popart/
Support Forums: http://smthemes.com/support/forum/popart-free-wordpress-theme/