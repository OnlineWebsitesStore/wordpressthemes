Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/educator/
Buy theme: http://smthemes.com/buy/educator/
Support Forums: http://smthemes.com/support/forum/educator-free-wordpress-theme