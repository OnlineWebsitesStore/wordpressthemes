Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/fusionarium/
Buy theme: http://smthemes.com/buy/fusionarium/
Support Forums: http://smthemes.com/support/forum/fusionarium-free-wordpress-theme/