Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/cherryradio/
Buy theme: http://smthemes.com/buy/cherryradio/
Support Forums: http://smthemes.com/support/forum/cherryradio-free-wordpress-theme/