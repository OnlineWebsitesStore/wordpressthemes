Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/taper/
Buy theme: http://smthemes.com/buy/taper/
Support Forums: http://smthemes.com/support/forum/taper-free-wordpress-theme/