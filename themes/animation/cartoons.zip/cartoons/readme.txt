Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/cartoons/
Buy theme: http://smthemes.com/buy/cartoons/
Support Forums: http://smthemes.com/support/forum/cartoons-free-wordpress-theme/