Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/warmwaves/
Buy theme: http://smthemes.com/buy/warmwaves/
Support Forums: http://smthemes.com/support/forum/warmwaves-free-wordpress-theme/