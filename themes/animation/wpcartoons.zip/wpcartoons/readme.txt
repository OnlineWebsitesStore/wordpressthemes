Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/wpcartoons/
Buy theme: http://smthemes.com/buy/wpcartoons/
Support Forums: http://smthemes.com/support/forum/wpcartoons-free-wordpress-theme/