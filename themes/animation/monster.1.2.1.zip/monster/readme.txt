== Changelog ==

= 1.2.1 - Jun 16 2015 =
* Escaping fixes
* Remove deprecated screen_icon() function
* Sanitize Theme Options setting in the Customizer

= 1.2 - Sep 25 2014 =
* Fix the position of the admin bar in small screens.
* Make sure header and main content are top of background image so that everything is clickable on small screens.
* Updated theme/author URIs and footer links to wordpress.com/themes.
* Reduced string proliferation.
* Removed hardcoded inclusion of wpcom.php.
* Moved away from using deprecated functions and improve compliance with .org theme review guidelines.
* Updated the footer credits.
* Better positioning of background elements with an active toolbar.

= 1.1 - Jan 3 2013 =
* Updated license.
* Added forward compatibility with 3.6.
* Removed min-height on header area when the header text is hidden.

= 1.0 - Jan 3 2013 =
* Initial release