Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/cartoo/
Buy theme: http://smthemes.com/buy/cartoo/
Support Forums: http://smthemes.com/support/forum/cartoo-free-wordpress-theme/