Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/prestig/
Buy theme: http://smthemes.com/buy/prestig/
Support Forums: http://smthemes.com/support/forum/prestig-free-wordpress-theme/