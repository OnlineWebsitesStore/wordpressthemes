Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/muse/
Buy theme: http://smthemes.com/buy/muse/
Support Forums: http://smthemes.com/support/forum/muse-free-wordpress-theme/